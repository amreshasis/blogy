const express = require("express");
const {
  getAllBlogs,
  createBlog,
  deleteBlog,
  updateBlog,
} = require("../controllers/blogsController");
const { verifyToken } = require("../controllers/auth");

const router = express.Router();

// Public route
router.get("/", getAllBlogs);

// Protected routes
router.post("/", verifyToken, createBlog);
router.put("/:id", verifyToken, updateBlog);
router.delete("/:id", verifyToken, deleteBlog);

module.exports = router;
