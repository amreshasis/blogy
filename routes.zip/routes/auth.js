const express = require("express");
const router = express.Router();

// Mock signup route
router.post("/signup", (req, res) => {
  const { email, password } = req.body;

  // Add logic to save the user to the database (e.g., hashing the password)
  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required" });
  }

  // Mock response for successful signup
  res.status(201).json({ message: "User registered successfully" });
});

module.exports = router;
